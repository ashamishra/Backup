# number_to_words
Takes input any number between 0-9999 and terminates if any other value
It converts it into words.
